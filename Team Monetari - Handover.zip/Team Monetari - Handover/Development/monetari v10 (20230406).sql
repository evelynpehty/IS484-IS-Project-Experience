DROP DATABASE monetari;
CREATE DATABASE IF NOT EXISTS monetari;
USE monetari;

-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: database.cxfozjjso73f.us-west-2.rds.amazonaws.com    Database: monetari
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
-- SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
-- SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

-- SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `credit_card`
--

DROP TABLE IF EXISTS `credit_card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `credit_card` (
  `creditCardAccountID` varchar(100) NOT NULL,
  `userID` int NOT NULL,
  `productID` int NOT NULL,
  `creditCardIssuer` varchar(50) NOT NULL,
  `creditCardLimit` float NOT NULL,
  `creditCardStartDate` date NOT NULL,
  `creditCardExpiryDate` date NOT NULL,
  `CVV` int NOT NULL,
  `status` varchar(50) NOT NULL,
  `chosenColor` varchar(255) NOT NULL,
  PRIMARY KEY (`creditCardAccountID`),
  KEY `credit_card_fk1` (`productID`),
  KEY `credit_card_fk2` (`userID`),
  CONSTRAINT `credit_card_fk1` FOREIGN KEY (`productID`) REFERENCES `product` (`productID`),
  CONSTRAINT `credit_card_fk2` FOREIGN KEY (`userID`) REFERENCES `user` (`userID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `credit_card`
--

LOCK TABLES `credit_card` WRITE;
/*!40000 ALTER TABLE `credit_card` DISABLE KEYS */;
INSERT INTO `credit_card` VALUES 
('1111',1,7,'Visa',10000,'2023-01-01','2028-01-01',888,'', "linear-gradient(to top right, #DBBB9E, #FF7D1F)"),
('1112',2,7,'Mastercard',5000,'2023-01-01','2028-01-01',999,'', "linear-gradient(to top right, #A4B6D2, #0085FF)"),
('1113',3,7,'Visa',2000,'2023-01-01','2028-01-01',101,'', "linear-gradient(to top right, #B5A4D2, #745DFF)");
/*!40000 ALTER TABLE `credit_card` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deposit_account`
--

DROP TABLE IF EXISTS `deposit_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deposit_account` (
  `depositAccountID` varchar(100) NOT NULL,
  `userID` int NOT NULL,
  `productID` int NOT NULL,
  `accountName` varchar(100) NOT NULL,
  `accountOpenDate` date NOT NULL,
  `accountCloseDate` date DEFAULT NULL,
  `availBalance` float NOT NULL,
  `pendingBalance` float NOT NULL,
  `currentStatus` varchar(50) NOT NULL,
  `interestRate` float NOT NULL,
  `depositTerm` int DEFAULT NULL,
  `openEmployeeID` int NOT NULL,
  `minimumAmount` float NOT NULL,
  `cardNo` varchar(50) DEFAULT NULL,
  `cardStartDate` date DEFAULT NULL,
  `cardExpiryDate` date DEFAULT NULL,
  `CVV` int DEFAULT NULL,
  `chosenColor` varchar(255) NOT NULL,
  PRIMARY KEY (`depositAccountID`),
  KEY `deposit_account_fk1` (`productID`),
  KEY `deposit_account_fk2` (`userID`),
  CONSTRAINT `deposit_account_fk1` FOREIGN KEY (`productID`) REFERENCES `product` (`productID`),
  CONSTRAINT `deposit_account_fk2` FOREIGN KEY (`userID`) REFERENCES `user` (`userID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deposit_account`
--

LOCK TABLES `deposit_account` WRITE;
/*!40000 ALTER TABLE `deposit_account` DISABLE KEYS */;
INSERT INTO `deposit_account` 
VALUES 
('123456789001',1,1,'Savings Account #1','2023-02-12','0000-00-00',23500,23500,'Active',2,0,1,500,'12345678','2023-02-12','2028-02-12',365, "linear-gradient(to top right, #A4B6D2, #0085FF)"),
('123456789002',1,2,'Current Account #1','2023-02-12','0000-00-00',8888,8888,'Active',2,0,1,500,'23456789','2023-02-12','2028-02-12',654, "linear-gradient(to top right, #B5A4D2, #745DFF)"),
('123456789003',2,1,'Savings Account #1','2023-02-12','0000-00-00',10000,10000,'Active',2,0,1,500,'12457803','2023-02-12','2028-02-12',234, "linear-gradient(to top right, #B5A4D2, #745DFF)"),
('123456789004',3,1,'Savings Account #1','2023-02-12','0000-00-00',10000,10000,'Active',2,0,1,500,'98403671','2023-02-12','2028-02-12',123, "linear-gradient(to top right, #D2A4C5, #FF42BF)"),
('123456789005',4,2,'Current Account #1','2023-02-12','0000-00-00',10000,10000,'Active',2,0,1,500,'33211464','2023-02-12','2028-02-12',163, "linear-gradient(to top right, #D2A4C5, #FF42BF)"),
('123456789006',5,2,'Current Account #1','2023-02-12','0000-00-00',10000,10000,'Active',2,0,1,500,'43543511','2023-02-12','2028-02-12',341, "linear-gradient(to top right, #E69F9F, #E60000)"),
('123456789007',6,2,'Current Account #1','2023-02-12','0000-00-00',10000,10000,'Active',2,0,1,500,'23432211','2023-02-12','2028-02-12',357, "linear-gradient(to top right, #DBBB9E, #FF7D1F)");
/*!40000 ALTER TABLE `deposit_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loan_account`
--

DROP TABLE IF EXISTS `loan_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `loan_account` (
  `loanAccountID` varchar(100) NOT NULL,
  `userID` int NOT NULL,
  `productID` int NOT NULL,
  `loanAccountName` varchar(100) NOT NULL,
  `loanStartDate` date NOT NULL,
  `loanMaturityDate` date NOT NULL,
  `loanTerm` int NOT NULL,
  `loanAmount` float NOT NULL,
  `loanBalance` float NOT NULL,
  `loanPurpose` varchar(100) NOT NULL,
  `ltvRatio` float DEFAULT NULL,
  `interestRate` float NOT NULL,
  `penaltyRate` float NOT NULL,
  `loanEmployeeID` int NOT NULL,
  `chosenColor` varchar(255) NOT NULL,
  PRIMARY KEY (`loanAccountID`),
  KEY `loan_account_fk1` (`productID`),
  KEY `loan_account_fk2` (`userID`),
  CONSTRAINT `loan_account_fk1` FOREIGN KEY (`productID`) REFERENCES `product` (`productID`),
  CONSTRAINT `loan_account_fk2` FOREIGN KEY (`userID`) REFERENCES `user` (`userID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loan_account`
--

LOCK TABLES `loan_account` WRITE;
/*!40000 ALTER TABLE `loan_account` DISABLE KEYS */;
INSERT INTO `loan_account`
VALUES 
('321456789001',1,3,"My Home Loan",'2022-12-15','2024-12-15',3,400000,390000,'Home',0.8,2.5,0,1,"linear-gradient(to top right, #E69F9F, #E60000)"),
('321456789002',1,4,"My Renovation Loan",'2022-12-14','2047-12-14',25,20000,150000,'Renovation',0,2,0,1, "linear-gradient(to top right, #DBBB9E, #FF7D1F)");
/*!40000 ALTER TABLE `loan_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loan_reminder`
--

DROP TABLE IF EXISTS `loan_reminder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `loan_reminder` (
  `loanReminderID` int NOT NULL AUTO_INCREMENT,
  `loanAccountID` varchar(100) NOT NULL,
  `ReminderType` varchar(250) NOT NULL,
  PRIMARY KEY (`loanReminderID`),
  CONSTRAINT `loan_reminder_fk1` FOREIGN KEY (`loanAccountID`) REFERENCES `loan_account` (`loanAccountID`)
);

--
-- Dumping data for table `loan_reminder`
--

LOCK TABLES `loan_reminder` WRITE;
/*!40000 ALTER TABLE `loan_reminder` DISABLE KEYS */;
INSERT INTO `loan_reminder` 
VALUES 
(1,'321456789001','Remind 3 days before deduction'),
(2,'321456789001','Remind 1 week before deduction'),
(3,'321456789002','Remind 1 day before deduction'),
(4,'321456789002','Remind 5 days before deduction');
/*!40000 ALTER TABLE `loan_reminder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `monthly_balance`
--

DROP TABLE IF EXISTS `monthly_balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `monthly_balance` (
  `balanceID` int NOT NULL AUTO_INCREMENT,
  `depositAccountID` varchar(100) NOT NULL,
  `yearMonth` date NOT NULL,
  `balance` float NOT NULL,
  PRIMARY KEY (`balanceID`),
  KEY `monthly_balance_fk1` (`depositAccountID`),
  CONSTRAINT `monthly_balance_fk1` FOREIGN KEY (`depositAccountID`) REFERENCES `deposit_account` (`depositAccountID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `monthly_balance`
--

LOCK TABLES `monthly_balance` WRITE;
/*!40000 ALTER TABLE `monthly_balance` DISABLE KEYS */;
INSERT INTO `monthly_balance` 
VALUES 
(1,'123456789001','2023-01-01',25030),
(2,'123456789003','2022-01-01',9970),
(3,'123456789001','2023-02-01',10000),
(4,'123456789001','2023-02-01',10000);
/*!40000 ALTER TABLE `monthly_balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `productID` int NOT NULL,
  `productName` varchar(255) NOT NULL,
  `productDescription` varchar(255) DEFAULT NULL,
  `status` varchar(50) NOT NULL,
  PRIMARY KEY (`productID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (1,'Savings Account','A savings account is a basic type of financial product that allows you to deposit your money and typically earn a modest amount of interest.','Active'),(2,'Current Account','A current account is a bank account where you can store and withdraw money','Active'),(3,'Home Loan','A home loan is a secured loan that is obtained to purchase a property by offering it as collateral.','Active'),(4,'Renovation Loan','A renovation loan is a financing solution that helps you better manage your cashflow.','Active'),(5,'Auto Loan','An auto loan allows you to borrow money from a lender and use that money to purchase a car.','Active'),(6,'Education Loan','An education loan is a sum of money borrowed to finance post-secondary education or higher education-related expenses','Active'),(7,'Credit Card','A credit card is a financial tool offered by a bank as a type of loan, with a line of revolving credit that you can access via your card','Active');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction_log`
--

DROP TABLE IF EXISTS `transaction_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction_log` (
  `transactionID` int NOT NULL,
  `transactionDate` datetime NOT NULL,
  `transactionDescription` varchar(255) NOT NULL,
  `transactionAmount` float NOT NULL,
  `transactionType` int NOT NULL,
  `accountFrom` varchar(100) DEFAULT NULL,
  `accountTo` varchar(100) NOT NULL,
  `exchangeRate` float NOT NULL,
  `currency` varchar(5) NOT NULL,
  `accountFrom_interimBalance` float DEFAULT NULL,
  `accountTo_interimBalance` float DEFAULT NULL,
  PRIMARY KEY (`transactionID`),
  KEY `transaction_log_fk1` (`transactionType`),
  CONSTRAINT `transaction_log_fk1` FOREIGN KEY (`transactionType`) REFERENCES `transaction_type` (`transactionTypeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_log`
--

LOCK TABLES `transaction_log` WRITE;
/*!40000 ALTER TABLE `transaction_log` DISABLE KEYS */;
INSERT INTO `transaction_log` 
VALUES 
(1,'2023-04-03 00:00:00','transfer for food',4500,107,'123456789001','123456789003',1,'SGD',10000,10000),
(2,'2023-04-01 00:00:00','',532,110,'123456789003','123456789001',1,'SGD',10030,0),
(3,'2023-03-31 00:00:00','',700,110,'123456789003','123456789001',1,'SGD',10030,0),
(4,'2023-03-30 00:00:00','',500,110,'123456789003','123456789001',1,'SGD',10030,0),
(5,'2023-03-11 00:00:00','',678,110,'123456789001','321456789002',1,'SGD',20030,0),
(6,'2023-02-17 00:00:00','',636,110,'123456789003','123456789001',1,'SGD',10030,0),
(7,'2023-02-14 00:00:00','',5677,110,'123456789001','321456789001',1,'SGD',10030,0),
(8,'2023-02-14 00:00:00','',123,110,'321456789002','123456789002',1,'SGD',20030,0),
(9,'2023-01-17 00:00:00','',6793,110,'123456789003','123456789001',1,'SGD',10030,0),
(10,'2023-01-01 00:00:00','',4500,110,'123456789001','321456789002',1,'SGD',20030,0),
(11,'2022-12-19 00:00:00','',5683,105,'','123456789001',1,'SGD',25030,0),
(12,'2022-12-19 00:00:00','',25030,105,'','123456789003',1,'SGD',9970,0),
(13,'2022-12-15 00:00:00','',2400,105,'123456789001','321456789002',1,'SGD',25030,0),
(14,'2022-12-14 00:00:00','',5000,110,'123456789001','321456789002',1,'SGD',20030,0),
(15,'2022-12-12 00:00:00','',10000,110,'321456789002','123456789001',1,'SGD',10030,0),
(16,'2022-11-14 00:00:00','',25030,105,'123456789002','321456789002',1,'SGD',25030,0),
(17,'2022-11-14 00:00:00','',25030,105,'321456789001','123456789002',1,'SGD',9970,0),
(18,'2022-11-12 00:00:00','',4000,105,'123456789002','321456789002',1,'SGD',25030,0),
(19,'2022-11-11 00:00:00','',1000,105,'123456789002','321456789002',1,'SGD',9970,0),
(20,'2022-11-04 00:00:00','',1234,105,'123456789001','321456789002',1,'SGD',25030,0),
(21,'2022-11-01 00:00:00','',4002,105,'321456789002','123456789001',1,'SGD',25030,0);
/*!40000 ALTER TABLE `transaction_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction_type`
--

DROP TABLE IF EXISTS `transaction_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction_type` (
  `transactionTypeID` int NOT NULL AUTO_INCREMENT,
  `transactionTypeName` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`transactionTypeID`)
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_type`
--

LOCK TABLES `transaction_type` WRITE;
/*!40000 ALTER TABLE `transaction_type` DISABLE KEYS */;
INSERT INTO `transaction_type` VALUES (100,'CASH_WITHDRAWAL'),(101,'ATM_WITHDRAWAL'),(102,'FEE_DEDUCTION'),(103,'PENALTY'),(104,'DEPOSIT_INTEREST'),(105,'CASH_DEPOSIT'),(106,'TERM_DEPOSIT'),(107,'FUND_TRANSFER'),(108,'LOAN_PRINCIPAL'),(109,'LOAN_INTEREST'),(110,'PARTIAL_LOAN_REPAYMENT'),(111,'FULL_LOAN_REPAYMENT'),(112,'POINT_OF_SALES'),(113,'BILL_PAYMENT'),(114,'CREDIT_CARD_PAYMENT');
/*!40000 ALTER TABLE `transaction_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `securities`
--

DROP TABLE IF EXISTS `securities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `securities` (
  `ticker` varchar(5) NOT NULL,
  `tickerName` varchar(255) NOT NULL,
  PRIMARY KEY (`ticker`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `securities`
--

LOCK TABLES `securities` WRITE;
/*!40000 ALTER TABLE `securities` DISABLE KEYS */;
INSERT INTO `securities` VALUES 
("AAPL", "Apple Inc"), ("TSLA", "Tesla Inc"), ("MSFT", "Microsoft Corp"), ("AMZN", "Amazon Inc"), ("GOOG", "Alphabet Inc Class C"), ("META", "Meta Platforms Inc"), ("WMT", "Walmart Inc"), ("NFLX", "Netflix Inc"), ("SBUX", "Starbucks Corp"), ("BABA", "Alibaba Group Holding Ltd - ADR");
/*!40000 ALTER TABLE `securities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `market_data`
--

DROP TABLE IF EXISTS `market_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `market_data` (
  `ticker` varchar(5) NOT NULL,
  `date` date NOT NULL,
  `openPrice` float NOT NULL,
  `highPrice` float NOT NULL,
  `lowPrice` float NOT NULL,
  `closingPrice` float NOT NULL,
  `volume` int NOT NULL,
  `dividends` int NOT NULL,
  `stockSplit` float NOT NULL,
  PRIMARY KEY (`ticker`, `date`),
  CONSTRAINT `market_data_fk1` FOREIGN KEY (`ticker`) REFERENCES `securities` (`ticker`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `market_data`
--

LOCK TABLES `market_data` WRITE;
/*!40000 ALTER TABLE `market_data` DISABLE KEYS */;
INSERT INTO `market_data` VALUES 
("AMZN", "2022-01-03", 167.550003, 170.703506,  166.160507, 170.404495, 63520000, 0, 0.0);
/*!40000 ALTER TABLE `market_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `watchlist`
--

DROP TABLE IF EXISTS `watchlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `watchlist` (
  `watchlistID` int NOT NULL AUTO_INCREMENT,
  `userID` int NOT NULL,
  `watchlistGroupName` varchar(255) NULL,
  PRIMARY KEY (`watchlistID`),
  CONSTRAINT `watchlist_fk1` FOREIGN KEY (`userID`) REFERENCES `user` (`userID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `watchlist`
--

LOCK TABLES `watchlist` WRITE;
/*!40000 ALTER TABLE `watchlist` DISABLE KEYS */;
INSERT INTO `watchlist` VALUES 
("1", "1","None"),
("2", "1","Technology"),
("3","1","Growth Stock");
/*!40000 ALTER TABLE `watchlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `watchlist_securities`
--

DROP TABLE IF EXISTS `watchlist_securities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `watchlist_securities` (
  `watchlistID` int NOT NULL AUTO_INCREMENT,
  `ticker` varchar(5) NOT NULL,
  `watchlistName` varchar(255) NULL,
  PRIMARY KEY (`watchlistID`, `ticker`),
  CONSTRAINT `watchlist_securities_fk1` FOREIGN KEY (`watchlistID`) REFERENCES `watchlist` (`watchlistID`),
  CONSTRAINT `watchlist_securities_fk2` FOREIGN KEY (`ticker`) REFERENCES `securities` (`ticker`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `watchlist_securities`
--

LOCK TABLES `watchlist_securities` WRITE;
/*!40000 ALTER TABLE `watchlist_securities` DISABLE KEYS */;
INSERT INTO `watchlist_securities` VALUES 
("2", "AAPL", ""),
("2", "GOOG", ""),
("1", "BABA", ""),
("2", "AMZN", ""),
("3", "TSLA", ""),
("1", "META", ""),
("1", "MSFT", "");
/*!40000 ALTER TABLE `watchlist_securities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `securities_holdings`
--

DROP TABLE IF EXISTS `securities_holdings`;
CREATE TABLE `securities_holdings` (
  `holdingsID` int NOT NULL AUTO_INCREMENT,
  `userID` int NOT NULL,
  PRIMARY KEY (`holdingsID`),
  CONSTRAINT `securities_holdings_fk1` FOREIGN KEY (`userID`) REFERENCES `user` (`userID`)
);
INSERT INTO `securities_holdings` VALUES (1, 1), (2, 2), (3, 3);

--
-- Table structure for table `all_holdings`
--

DROP TABLE IF EXISTS `all_holdings`;
CREATE TABLE `all_holdings` (
  `holdingsID` int NOT NULL AUTO_INCREMENT,
  `ticker` varchar(5) NOT NULL,
  `qty` int NOT NULL,
  `buy_price` float NOT NULL,
  PRIMARY KEY (`holdingsID`, `ticker`),
  CONSTRAINT `all_holdings_fk1` FOREIGN KEY (`holdingsID`) REFERENCES `securities_holdings` (`holdingsID`),
  CONSTRAINT `all_holdings_fk2` FOREIGN KEY (`ticker`) REFERENCES `securities` (`ticker`)
);
INSERT INTO `all_holdings` VALUES 
(1, "AAPL", 30, 155.00), (1, "TSLA", 20, 180.93);



--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `userID` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `lastLoginTimeStamp` varchar(30) NOT NULL,
  PRIMARY KEY (`userID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'evelynpeh','123123','1677580003'),(2,'peiling','123123','1677515320'),(3,'jaytoo','123123','1552469767'),(4,'wanxin','123123','1552469767'),(5,'cheyenne','123123','1552469767'),(6,'ningxian','123123','1677231969');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_details`
--

DROP TABLE IF EXISTS `user_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_details` (
  `userID` int NOT NULL,
  `familyName` varchar(100) NOT NULL,
  `givenName` varchar(100) NOT NULL,
  `taxIdentifier` varchar(100) NOT NULL,
  `dateOfBirth` date NOT NULL,
  `postalCode` varchar(6) NOT NULL,
  `addressLine1` varchar(255) NOT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `country` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `countryCode` varchar(3) NOT NULL,
  `phoneNo` varchar(15) NOT NULL,
  `homeNo` varchar(15) NOT NULL,
  `registrationDate` datetime NOT NULL,
  `nationality` varchar(255) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `ethnicity` varchar(255) NOT NULL,
  `occupation` varchar(255) DEFAULT NULL,
  `jobTitle` varchar(255) DEFAULT NULL,
  `employerName` varchar(255) DEFAULT NULL,
  `maritalStatus` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `chosenColor` varchar(6) NOT NULL,
  PRIMARY KEY (`userID`),
  CONSTRAINT `user_details_fk1` FOREIGN KEY (`userID`) REFERENCES `user` (`userID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_details`
--

LOCK TABLES `user_details` WRITE;
/*!40000 ALTER TABLE `user_details` DISABLE KEYS */;
INSERT INTO `user_details` VALUES (1,'Peh','Evelyn','t1122345a','2000-12-19','670413','Blk 413 Saujana Road','','Singapore','Singapore','Singapore','65','92331476','67601427','2023-02-12 00:00:00','Singaporean','Female','Chinese','Student','','','Single','evelyn.peh.2020@scis.smu.edu.sg','FFCE30'),(2,'Koh','Pei Ling','t1222345b','1999-10-03','670412','Blk 412 Saujana Road','','Singapore','Singapore','Singapore','65','97663055','67633081','2023-02-12 00:00:00','Singaporean','Female','Chinese','Student','','','Single','peiling.koh.2020@scis.smu.edu.sg','E83845'),(3,'Too','Min Jay','t1322345c','1999-01-09','670411','Blk 411 Saujana Road','','Singapore','Singapore','Singapore','65','99988874','67601426','2023-02-12 00:00:00','Singaporean','Male','Chinese','Student','','','Single','minjay.too.2020@scis.smu.edu.sg','E389B9'),(4,'Wan','Xin','t1422345d','1996-01-26','670414','Blk 414 Saujana Road','','Singapore','Singapore','Singapore','65','98272352','65437688','2023-02-12 00:00:00','China','Male','Chinese','Student','','','Single','xin.wan.2020@scis.smu.edu.sg','FFCE30'),(5,'Loh','Cheyenne','t1522345e','2001-11-06','670415','Blk 415 Saujana Road','','Singapore','Singapore','Singapore','65','98765432','67890123','2023-02-12 00:00:00','Singaporean','Female','Chinese','Student','','','Single','cheyenneloh.2020@scis.smu.edu.sg','FF1919'),(6,'Jin','Ning Xian','t1622345f','1999-07-08','670416','Blk 416 Saujana Road','','Singapore','Singapore','Singapore','65','90303567','67421300','2023-02-12 00:00:00','China','Male','Chinese','Student','','','Single','ningxianjin.2020@scis.smu.edu.sg','E389B9');
/*!40000 ALTER TABLE `user_details` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-28 18:50:40
